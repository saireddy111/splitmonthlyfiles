﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProlificMonthlyStatement.Models
{
    public class ClientModel
    {
        public string Client { get; set; }
        public string GroupNumber { get; set; }
        public string AssociationNumber { get; set; }
        public string MerchantNumber { get; set; }
        public string MerchantDBAName { get; set; }
        public string MerchantPricingMonthEndIDDisplay { get; set; }
        public string MerchantPricingCategoryDescription { get; set; }
        public string MerchantPricingFeeItemName_Billed { get; set; }
        public string MerchantPricingKey2Description { get; set; }
        public string MerchantPricingGrossCount { get; set; }
        public string MerchantPricingNetAmount { get; set; }
        public string MerchantPricingFeePerItemRate { get; set; }
        public string MerchantPricingFeePercentage { get; set; }
        public string MerchantPricingInterchangePerItemRate { get; set; }
        public string MerchantPricingInterchangePercentRate { get; set; }
        public string MerchantPricingTotalFees { get; set; }
    }

   /* public class ModelClassMap : ClassMap<ClientModel>
    {
        public ModelClassMap()
        {
            Map(m => m.Client).Name("Client");
            Map(m => m.GroupNumber).Name("Group Number");
            Map(m => m.AssociationNumber).Name("Association Number");
            Map(m => m.MerchantNumber).Name("Merchant Number");
            Map(m => m.MerchantDBAName).Name("Merchant DBA Name");
            Map(m => m.MerchantPricingMonthEndIDDisplay).Name("Merchant Pricing Month End ID Display");
            Map(m => m.MerchantPricingCategoryDescription).Name("Merchant Pricing Category Description");
            Map(m => m.MerchantPricingFeeItemName_Billed).Name("Merchant Pricing Fee Item Name - Billed");
            Map(m => m.MerchantPricingKey2Description).Name("Merchant Pricing Key 2 Description");
            Map(m => m.MerchantPricingGrossCount).Name("Merchant Pricing Gross Count");
            Map(m => m.MerchantPricingNetAmount).Name("Merchant Pricing Net Amount");
            Map(m => m.MerchantPricingFeePerItemRate).Name("Merchant Pricing Fee Per Item Rate");
            Map(m => m.MerchantPricingFeePercentage).Name("Merchant Pricing Fee Percentage");
            Map(m => m.MerchantPricingInterchangePerItemRate).Name("Merchant Pricing Interchange Per Item Rate");
            Map(m => m.MerchantPricingInterchangePercentRate).Name("Merchant Pricing Interchange Percent Rate");
            Map(m => m.MerchantPricingTotalFees).Name("Merchant Pricing Total Fees");
        }
    }*/

}
